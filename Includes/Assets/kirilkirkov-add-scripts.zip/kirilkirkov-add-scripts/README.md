# Add scripts

<p>This plugin integrates your scripts into the header of your theme. If your theme doesn’t include default header or header, then I’d recommend getting another theme. A well-written theme will always include this, and if it doesn’t, who’s to say where else there may be problems?</p>

<a href="https://github.com/Wordpress-Plugins-World/kirilkirkov-add-scripts/blob/master/Includes/Assets/kirilkirkov-add-scripts.zip?raw=true" download>Click to Download</a>

![alt text](https://github.com/Wordpress-Plugins-World/kirilkirkov-add-scripts/blob/master/Includes/Assets/admin-preview.png?raw=true)
